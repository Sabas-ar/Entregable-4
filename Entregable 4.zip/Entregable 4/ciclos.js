function realizarOperacion(){ 
        let continuar=true;
        while (continuar) {


    let num1 = parseFloat(prompt("ingrese valor"));
    let num2 = parseFloat(prompt("ingrese valor"));
    let operacion = prompt("ingrese la operacion a realicar(+-*/) y si desea salir escriba salir");
    let resultado = (num1, num2);

    if (operacion == "+") {
        resultado = num1 + num2;
    } else if (operacion === "-") { 
        resultado = num1 - num2;
    } else if (operavio === "*")  {
        resultado = num1 * num2;
    } else if (operacion === "/") {
        if (num1 !==0) { 
            resultado = num1 / num2;  
        } else { 
             resultado = ("no se puede dividir entre 0");}



    } else if (operacion === "salir") {
           continuar=false 
           document.write() 
            break;  
    }else{         
           resultado = ("error de la operacion" )
            }       

        document.write("el resultaso es: " + resultado + "<br>");  
        
    }
}
      realizarOperacion();


